cd bin
java -Djava.library.path="../lib" -jar RabiClone.jar
cd ..