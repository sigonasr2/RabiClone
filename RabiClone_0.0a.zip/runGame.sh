cd bin
java -cp lib/bin -Djava.library.path="lib" -jar RabiClone.jar
cd ..