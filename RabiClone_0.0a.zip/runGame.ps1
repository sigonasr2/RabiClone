cd bin
java "-Djava.library.path=../lib" -Xms2G -Xmx2G -XX:+PrintCommandLineFlags -version -jar RabiClone.jar
cd ..