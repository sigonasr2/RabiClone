cd bin
java -jar RabiClone.jar
cd ..