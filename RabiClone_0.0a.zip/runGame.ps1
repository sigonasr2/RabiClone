cd bin
java "-Djava.library.path=../lib" -Xms2G -Xmx2G -jar RabiClone.jar
cd ..